/// <reference types="react" />
import { ContentProps } from "./Content.types";
declare const Content: (props: ContentProps) => JSX.Element;
export default Content;
export declare const NoImage: (props: ContentProps) => JSX.Element;
